﻿using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Project2.Models;

namespace Project2.Models
{
    public class Order
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]

        public string Id { get; set; }
        public string RowID { get; set; }
        public string OrderID  { get; set; }

        public string OrderDate { get; set; }
     
        public string ShipDate { get; set; }
  
        public string ShipMode { get; set; }
    
        public string CustomerID { get; set; }
    
        public string Segment { get; set; }
        public string PostalCode { get; set; }
        public string City { get; set; }

        public string State { get; set; }
        public string Country { get; set; }
  
        public string Region { get; set; }
   
        public string Market { get; set; }

        public string ProductID { get; set; }
 
        public string Category { get; set; }
  
        public string SubCategory { get; set; }
        public string ProductName { get; set; }
        public string Sales { get; set; }

        public string Quantity { get; set; }
 
        public string Discount { get; set; }
        public string Profit { get; set; }
  
        public string ShippingCost { get; set; }
    
        public string OrderPriority { get; set; }

   
        }
}

