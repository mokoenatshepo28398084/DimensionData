﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BrightHouseApp.Models;
using BrightHouseApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BrightHouseApp.Controllers
{
    public class AccountController : Controller
    {

        private readonly AccountService accountService;

        public AccountController(AccountService accountService)
        {
            this.accountService = accountService;
        }
        public IActionResult Login()
        {
            return View();
        }
        public ActionResult Validate(Admins admin)
        {

            var _admin = accountService.Get().Where(x => x.Email == admin.Email);


            if (_admin.Where(s => s.Password == admin.Password).Any())
            {

                return Json(new { status = true, message = "Login Successfull!" });
            }
            else
            {
                return Json(new { status = false, message = "Invalid Password!" });
            }

        }

        // GET: Account/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Account/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Account/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Admins admin)
        {
            if(ModelState.IsValid)
            {
                accountService.Create(admin);

                return RedirectToAction(nameof(Login));
            }

            return View(admin);
          
        }

        // GET: Account/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Account/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Login));
            }
            catch
            {
                return View();
            }
        }

        // GET: Account/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Account/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Login));
            }
            catch
            {
                return View();
            }
        }
    }
}