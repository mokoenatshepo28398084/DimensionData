﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BrightHouseApp.Models;
using BrightHouseApp.Services;

namespace BrightHouseApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly PeopleService peopleService;
        private PeopleInfoView info = new PeopleInfoView();

        public HomeController(PeopleService peopleService)
        {
            this.peopleService = peopleService;
        }
        public IActionResult Index()
        {
            
         
           var countA = peopleService.Get();
           //int totalafrica_count = (from x in countA.Where (x => x.Region.Contains("Africa")) select x.Person).Count(); 
          // info.africa_count = totalafrica_count;
           return View(info);
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
