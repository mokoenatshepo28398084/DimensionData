﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using Project2.Models;

namespace Project2.Services
{
    public class OrderService
    {
       private readonly IMongoCollection<Order> orders;

        public OrderService(IConfiguration config)
        {
           // MongoClient client = new MongoClient(config.GetConnectionString("GlobalStore"));
            MongoClient client = new MongoClient(config.GetConnectionString("Britehousedb"));
            IMongoDatabase database = client.GetDatabase("Britehousedb");
            orders = database.GetCollection<Order>("Orders");
        }

        public List<Order> Get()
        {
            return orders.Find(order => true).ToList();
        }

        public Order Get(string id)
        {
            return orders.Find(order => order.Id == id).FirstOrDefault();
        }

        public Order Create(Order order)
        {
            orders.InsertOne(order);
            return order;
        }

        public void Update(string id, Order orderIn)
        {
            orders.ReplaceOne(order => order.Id == id, orderIn);
        }

        public void Remove(Order orderIn)
        {
            orders.DeleteOne(order => order.Id == orderIn.Id);
        }

        public void Remove(string id)
        {
            orders.DeleteOne(order => order.Id == id);
        }
    }
}
