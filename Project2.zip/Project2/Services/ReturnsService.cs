﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using Project2.Models;

namespace  Project2.Models.Services
{
    public class ReturnsService
    {
        private readonly IMongoCollection<Returns> returns;

        public ReturnsService(IConfiguration config)
        {
            MongoClient client = new MongoClient(config.GetConnectionString("Britehousedb"));
            IMongoDatabase database = client.GetDatabase("Britehousedb");
            returns = database.GetCollection<Returns>("Returns");
        }

        public List<Returns> Get()
        {
            return returns.Find(returnsL => true).ToList();
        }

        public Returns Get(string id)
        {
            return returns.Find(returnsL => returnsL.Id == id).FirstOrDefault();
        }

        public Returns Create(Returns returnsL)
        {
            returns.InsertOne(returnsL);
            return returnsL;
        }

        public void update(string id, Returns returnsLIn)
        {
            returns.ReplaceOne(returnsL => returnsL.Id == id, returnsLIn);
        }

        public void Remove(Returns returnsLIn)
        {
            returns.DeleteOne(returnsL => returnsL.Id == returnsLIn.Id);
        }

        public void Remove(string id)
        {
            returns.DeleteOne(returnsL => returnsL.Id == id);
        }
    }
}
