﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Project2.Models;
using MongoDB.Driver;

namespace Project2.Services
{
    public class PeopleService
    {
        private readonly IMongoCollection<People> people;

        public PeopleService(IConfiguration config)
        {
            MongoClient client = new MongoClient(config.GetConnectionString("Britehousedb"));
            IMongoDatabase database = client.GetDatabase("Britehousedb");
            people = database.GetCollection<People>("People");
        }

        public List<People> Get()
        {
            return people.Find(_people => true).ToList();
        }

        public People Get(string id)
        {
            return people.Find(_people => _people.Id == id).FirstOrDefault();
        }

        public People Create(People _people)
        {
            people.InsertOne(_people);
            return _people;
        }

        public void Update(string id, People peopleIn)
        {
            people.ReplaceOne(_people => _people.Id == id, peopleIn);
        }

        public void Remove(People peopleIn)
        {
            people.DeleteOne(_people => _people.Id == peopleIn.Id);
        }

        public void Remove(string id)
        {
            people.DeleteOne(_people => _people.Id == id);
        }
    }
}
    

